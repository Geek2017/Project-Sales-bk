#!/bin/bash

if [[ -z "${C9PROJECT}" ]]; then
        C9PROJECT="c9"
fi

if [[ -z "${C9USER}" ]]; then
	C9USER="pacific"
fi

cd /core
/usr/bin/node server.js --collab --listen 0.0.0.0 -p 8080 -a $C9USER:$C9PASS -w /workdir


